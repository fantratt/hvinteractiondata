var require = meteorInstall({"imports":{"api":{"querys.js":["meteor/mongo",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/api/querys.js                                                                              //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
exports.__esModule = true;                                                                            //
exports.Missions = exports.Interactions = exports.Users = undefined;                                  //
                                                                                                      //
var _mongo = require('meteor/mongo');                                                                 // 1
                                                                                                      //
//export const Interactions = new Mongo.Collection('interactions');                                   //
//export const Users = new Mongo.Collection('users');                                                 //
var database;                                                                                         // 4
if (Meteor.isServer) {                                                                                // 5
  var database = new MongoInternals.RemoteCollectionDriver("mongodb://127.0.0.1:3001/meteor");        // 7
}                                                                                                     //
var Users = exports.Users = new _mongo.Mongo.Collection('users', { _driver: database });              // 9
var Interactions = exports.Interactions = new _mongo.Mongo.Collection('Logs', { _driver: database });
var Missions = exports.Missions = new _mongo.Mongo.Collection('MissionLines', { _driver: database });
////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"ui":{"interactionflow.js":["meteor/templating","../imports/api/querys.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// ui/interactionflow.js                                                                              //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var _templating = require('meteor/templating');                                                       // 1
                                                                                                      //
var _querys = require('../imports/api/querys.js');                                                    // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"server":{"main.js":["meteor/meteor","../imports/api/querys.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// server/main.js                                                                                     //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var _meteor = require('meteor/meteor');                                                               // 1
                                                                                                      //
require('../imports/api/querys.js');                                                                  // 2
                                                                                                      //
_meteor.Meteor.startup(function () {});                                                               // 4
////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./ui/interactionflow.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
