(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['hot-code-push'] = {};

})();
